# -*- coding: utf-8 -*-
"""
Hokonui

common library for accessing bitcoin exchanges
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

"""

__title__ = "hokonui"
__version__ = "1.2.0"
__build__ = 0x000000
__author__ = "laisee@github"
__license__ = "MIT"
